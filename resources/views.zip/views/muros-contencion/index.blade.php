<x-app-layout>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"
        integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <div class="muros-contencion-container py-2 font-serif" x-data="mainSystem">
        <!-- Tab Navigation -->
        <div
            class="bg-gradient-to-r from-cyan-50 to-blue-50 rounded-lg shadow-lg mb-4 overflow-hidden bg-white/80 backdrop-blur-lg border-b border-slate-200/60 shadow-lg sticky top-0 z-50">
            <div class="border-b border-blue-100">
                <div class="overflow-x-auto scrollbar-hide">
                    <nav class="flex whitespace-nowrap min-w-full">
                        <template x-for="tab in tabs" :key="tab.id">
                            <button @click="changeTab(tab.id)"
                                :class="activeTab === tab.id ?
                                    'border-cyan-500 bg-gradient-to-b from-cyan-50 to-blue-50 text-cyan-700' :
                                    'border-transparent text-gray-600 hover:text-cyan-600 hover:bg-cyan-50/50'"
                                class="flex items-center space-x-2 px-4 py-3 border-b-2 font-medium text-xs transition-all duration-200">
                                <i :class="'fas ' + tab.icon + ' text-xs'"></i>
                                <span x-text="tab.name" class="hidden sm:inline"></span>
                                <span x-text="tab.name.split(' ')[0]" class="sm:hidden"></span>
                            </button>
                        </template>
                    </nav>
                </div>
            </div>
        </div>

        <!-- Tab Content -->
        <div class="bg-gradient-to-br from-white to-cyan-50/30 rounded-lg shadow-lg border border-blue-100/50">
            <!-- Demanda Diaria Tab -->
            <div x-show="activeTab === 'demandaDiaria'" x-transition>
                <div id="demandaDiaria-content"></div>
            </div>

            <!-- Cisterna Tab -->
            <div x-show="activeTab === 'cisterna'" x-transition>
                <div id="cisterna-content"></div>
            </div>

            <!-- Tanque Tab -->
            <div x-show="activeTab === 'tanque'" x-transition>
                <div id="tanque-content"></div>
            </div>

            <!-- Red Alimentacion Tab -->
            <div x-show="activeTab === 'redAlimentacion'" x-transition>
                <div id="red-alimentacion-content"></div>
            </div>

            <!-- Maxima demanda simultanea Tab -->
            <div x-show="activeTab === 'maximademandasimultanea'" x-transition>
                <div id="maximademanda-simultanea-content"></div>
            </div>

            <!-- Bombeo al Tanque Elevado Tab -->
            <div x-show="activeTab === 'bombeoTanqueElevado'" x-transition>
                <div id="bombeo-tanque-elevado-content"></div>
            </div>

            <!-- Tuberia RD Grades Tab -->
            <div x-show="activeTab === 'tuberiasRD'" x-transition>
                <div id="tuberias-rd-grades-content"></div>
            </div>

            <!-- Redes Interiores Grades Tab -->
            <div x-show="activeTab === 'redesInteriores'" x-transition>
                <div id="redes-interiores-grades-content"></div>
            </div>

            <!-- Red de Riego Tab -->
            <div x-show="activeTab === 'redRiego'" x-transition>
                <div id="red-griego-content"></div>
            </div>
        </div>
    </div>

    @pushOnce('scripts')
        {{-- Alpine.js se carga solo desde Vite, no desde CDN --}}
        @vite(['resources/js/muros-contencion/main.js'])
    @endpushOnce
</x-app-layout>
