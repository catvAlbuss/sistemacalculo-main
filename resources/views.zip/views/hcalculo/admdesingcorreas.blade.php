@pushOnce('scripts')
  @vite('resources/js/adm_correa.js')
@endpushOnce

<x-calc-layout title="Diseño de correas">
  <div class="container mx-auto flex flex-wrap py-12">
    <!-- Formulario -->
    <div class="w-full overflow-auto rounded-lg bg-white p-6 shadow-md md:w-1/3 dark:bg-gray-800">
      <h3 class="mb-4 text-xl font-semibold text-gray-800 dark:text-gray-200">Datos Generales</h3>
      <table class="w-full table-fixed px-6 text-gray-800 dark:text-white">
        <thead class="bg-white dark:bg-gray-800">
          <tr class="text-center">
            <th class="px-4 py-2">Nombre</th>
            <th class="px-4 py-2">Simb.</th>
            <th class="px-4 py-2">Entrada</th>
            <th class="px-4 py-2">Unidad <br> Medida</th>
          </tr>
        </thead>
        <tbody class="text-center">
          <tr class="bg-white dark:bg-gray-800">
            <th class="px-4 py-2">-</th>
            <th class="px-4 py-2">-</th>
            <th class="px-4 py-2">
              <select
                class="form-control w-full rounded-md bg-gray-50 p-2 px-1 text-gray-800 dark:bg-gray-700 dark:text-gray-200"
                id="selectabc" name="selectabc">
                <option value="A" selected>A</option>
                <option value="B">B</option>
                <option value="C">C</option>
              </select>
              <!-- <input class="form-control w-full rounded-md bg-gray-50 p-2 px-1 text-gray-800 dark:bg-gray-700 dark:text-gray-200" id="fc" name="fc" type="text" value="2" placeholder="2" min="0" required> -->
            </th>
            <th class="px-4 py-2">pulg</th>
          </tr>
          <tr class="bg-white dark:bg-gray-800">
            <th class="px-4 py-2">-</th>
            <th class="px-4 py-2">b= </th>
            <th class="px-4 py-2">
              <input
                class="form-control w-full rounded-md bg-gray-50 p-2 px-1 text-gray-800 dark:bg-gray-700 dark:text-gray-200"
                id="fcprime" name="fcprime" type="text" value="2" placeholder="2" min="0" required>
            </th>
            <th class="px-4 py-2">pulg</th>
          </tr>
          <tr class="bg-white dark:bg-gray-800">
            <th class="px-4 py-2">-</th>
            <th class="px-4 py-2">h=</th>
            <th class="px-4 py-2"><input
                class="form-control w-full rounded-md bg-gray-50 p-2 px-1 text-gray-800 dark:bg-gray-700 dark:text-gray-200"
                id="fy" name="fy" type="text" value="4" placeholder="4" min="0" required>
            </th>
            <th class="px-4 py-2">pulg</th>
          </tr>
          <tr class="bg-white dark:bg-gray-800">
            <th class="px-4 py-2">-</th>
            <th class="px-4 py-2">L=</th>
            <th class="px-4 py-2"><input
                class="form-control w-full rounded-md bg-gray-50 p-2 px-1 text-gray-800 dark:bg-gray-700 dark:text-gray-200"
                id="base" name="base" type="text" value="2.5" placeholder="base" min="0" required
                oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
            </th>
            <th class="px-4 py-2">m</th>
          </tr>
          <tr class="bg-white dark:bg-gray-800">
            <th class="px-4 py-2">-</th>
            <th class="px-4 py-2">S=</th>
            <th class="px-4 py-2"><input
                class="form-control w-full rounded-md bg-gray-50 p-2 px-1 text-gray-800 dark:bg-gray-700 dark:text-gray-200"
                id="altura" name="altura" type="text" value="0.75" placeholder="Numero de TRAMOS"
                min="0" required
                oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"></th>
            <th class="px-4 py-2">m</th>
          </tr>
          <tr class="bg-white dark:bg-gray-800">
            <th class="px-4 py-2">PESO PROPIO</th>
            <th class="px-4 py-2">-</th>
            <th class="px-4 py-2"><input
                class="form-control w-full rounded-md bg-gray-50 p-2 px-1 text-gray-800 dark:bg-gray-700 dark:text-gray-200"
                id="momentoultimo" name="momentoultimo" type="text" value="10" placeholder="Numero de TRAMOS"
                min="0" required
                oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"></th>
            <th class="px-4 py-2">Kg/m<sup>2</sup></th>
          </tr>
          <tr class="bg-white dark:bg-gray-800">
            <th class="px-4 py-2">COVERTURA</th>
            <th class="px-4 py-2">-</th>
            <th class="px-4 py-2"><input
                class="form-control w-full rounded-md bg-gray-50 p-2 px-1 text-gray-800 dark:bg-gray-700 dark:text-gray-200"
                id="vucortante" name="vucortante" type="text" value="20" placeholder="Numero de TRAMOS"
                min="0" required
                oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"></th>
            <th class="px-4 py-2">Kg/m<sup>2</sup></th>
          </tr>

          <tr class="bg-white dark:bg-gray-800">
            <th class="px-4 py-2">CIELO RASO</th>
            <th class="px-4 py-2">-</th>
            <th class="px-4 py-2"><input
                class="form-control w-full rounded-md bg-gray-50 p-2 px-1 text-gray-800 dark:bg-gray-700 dark:text-gray-200"
                id="cieloraso" name="cieloraso" type="text" value="0" placeholder="Numero de TRAMOS"
                min="0" required
                oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"></th>
            <th class="px-4 py-2">Kg/m<sup>2</sup></th>
          </tr>
          <tr class="bg-white dark:bg-gray-800">
            <th class="px-4 py-2">SOBRE CARGA</th>
            <th class="px-4 py-2">-</th>
            <th class="px-4 py-2"><input
                class="form-control w-full rounded-md bg-gray-50 p-2 px-1 text-gray-800 dark:bg-gray-700 dark:text-gray-200"
                id="sobrecarga" name="sobrecarga" type="text" value="60" placeholder="Numero de TRAMOS"
                min="60" required
                oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"></th>
            <th class="px-4 py-2">Kg/m<sup>2</sup></th>
          </tr>
          <tr>
            <th class="px-4 py-2">
              <div class="input-group mb-2">
                <button
                  class="rounded border-b-4 border-blue-700 bg-blue-500 px-4 py-2 font-bold text-white hover:border-blue-500 hover:bg-blue-400"
                  id="desingButton" type="button">DISEÑAR</button>
              </div>
            </th>
          </tr>
          <!-- Agregar más filas según sea necesario -->
        </tbody>
      </table>
    </div>
    <!-- Resultados -->
    <div class="mt-4 w-full px-4 md:mt-0 md:w-2/3">
      <div class="rounded-lg bg-white p-6 shadow-md dark:bg-gray-800">
        <h3 class="mb-4 text-xl font-semibold text-gray-800 dark:text-gray-200">Resultados</h3>
        <div class="overflow-x-auto">
          <table class="min-w-full text-gray-800 dark:text-white" id="desingcorte">
            <!-- Requisitos de diseño vigas -->
            <thead class="bg-gray-200 dark:bg-gray-800">
              <tr class="bg-white text-gray-900 dark:bg-gray-800 dark:text-white">
                <th class="px-4 py-2 text-left text-xl" colspan="4">1.- Propiedades del tipo de madera</th>
              </tr>
              <tr class="bg-gray-500 text-white dark:bg-gray-500 dark:text-white">
                <th class="px-4 py-2 text-lg" scope="col">Nombre</th>
                <th class="px-4 py-2 text-lg" scope="col">Símbolo</th>
                <th class="px-4 py-2 text-lg" scope="col">Fórmula</th>
                <th class="px-4 py-2 text-lg" scope="col">Resultado</th>
              </tr>
            </thead>
            <tbody class="bg-gray-100 py-2 dark:bg-gray-800" id="predimenension"></tbody>

            <thead class="bg-gray-200 dark:bg-gray-800">
              <tr class="bg-white text-gray-900 dark:bg-gray-800 dark:text-white">
                <th class="px-4 py-2 text-left text-xl" colspan="4">2.- Dimensionamiento </th>
              </tr>
              <tr class="bg-gray-500 text-white dark:bg-gray-500 dark:text-white">
                <th class="px-4 py-2 text-lg" scope="col">Nombre</th>
                <th class="px-4 py-2 text-lg" scope="col">Símbolo</th>
                <th class="px-4 py-2 text-lg" scope="col">Fórmula</th>
                <th class="px-4 py-2 text-lg" scope="col">Resultado</th>
              </tr>
            </thead>
            <tbody class="bg-gray-100 py-2 dark:bg-gray-800" id="dimensionamiento"></tbody>

            <!-- 2.- Combinacion de Cargas -->

            <thead class="bg-gray-200 dark:bg-gray-800">
              <tr class="bg-white text-gray-900 dark:bg-gray-800 dark:text-white">
                <th class="px-4 py-2 text-left text-xl" colspan="4">2.- Combinacion de Cargas </th>
              </tr>
              <tr class="bg-gray-500 text-white dark:bg-gray-500 dark:text-white">
                <th class="px-4 py-2 text-lg" scope="col">Nombre</th>
                <th class="px-4 py-2 text-lg" scope="col">Símbolo</th>
                <th class="px-4 py-2 text-lg" scope="col">Fórmula</th>
                <th class="px-4 py-2 text-lg" scope="col">Resultado</th>
              </tr>
            </thead>

            <tbody class="bg-gray-100 py-2 dark:bg-gray-800" id="combinaciondecargas"></tbody>
            <!-- 3.- Analisi estructural -->
            <thead class="bg-gray-200 dark:bg-gray-800">
              <tr class="bg-white text-gray-900 dark:bg-gray-800 dark:text-white">
                <th class="px-4 py-2 text-left text-xl" colspan="4">3.- Analisi estructural</th>
              </tr>
              <tr class="bg-gray-500 text-white dark:bg-gray-500 dark:text-white">
                <th class="px-4 py-2 text-lg" scope="col">Nombre</th>
                <th class="px-4 py-2 text-lg" scope="col">Símbolo</th>
                <th class="px-4 py-2 text-lg" scope="col">Fórmula</th>
                <th class="px-4 py-2 text-lg" scope="col">Resultado</th>
              </tr>
            </thead>
            <tbody class="bg-gray-100 py-2 dark:bg-gray-800" id="analisisestructural"></tbody>
            <!-- 5.- Diseño en madera -->
            <thead class="bg-gray-200 dark:bg-gray-700">
              <tr class="bg-white text-gray-900 dark:bg-gray-800 dark:text-white">
                <th class="px-4 py-2 text-left text-xl" colspan="4">4.- Diseño en madera</th>
              </tr>
              <tr class="bg-gray-500 text-white dark:bg-gray-500 dark:text-white">
                <th class="text-xl" scope="col">Nombre</th>
                <th class="text-xl" scope="col">Simbolo</th>
                <th class="text-xl" scope="col">Formula</th>
                <th class="text-xl" scope="col">Resultado</th>
              </tr>
            </thead>
            <tbody class="py-2" id="desingFlexion"></tbody>

            <thead class="bg-gray-200 dark:bg-gray-700">
              <tr class="bg-white text-gray-900 dark:bg-gray-800 dark:text-white">
                <th class="px-4 py-2 text-left text-xl" colspan="4">4.1- Vereficacion del modulo de seccion
                </th>
              </tr>
              <tr class="bg-gray-500 text-white dark:bg-gray-500 dark:text-white">
                <th class="text-xl" scope="col">Nombre</th>
                <th class="text-xl" scope="col">Simbolo</th>
                <th class="text-xl" scope="col">Formula</th>
                <th class="text-xl" scope="col">Resultado</th>
              </tr>
            </thead>
            <tbody class="py-2" id="modulo41"></tbody>

            <thead class="bg-gray-200 dark:bg-gray-700">
              <tr class="bg-white text-gray-900 dark:bg-gray-800 dark:text-white">
                <th class="px-4 py-2 text-left text-xl" colspan="4">4.2- Vereficacion de inercias</th>
              </tr>
              <tr class="bg-gray-500 text-white dark:bg-gray-500 dark:text-white">
                <th class="text-xl" scope="col">Nombre</th>
                <th class="text-xl" scope="col">Simbolo</th>
                <th class="text-xl" scope="col">Formula</th>
                <th class="text-xl" scope="col">Resultado</th>
              </tr>
            </thead>
            <tbody class="py-2" id="modulo42"></tbody>

            <thead class="bg-gray-200 dark:bg-gray-700">
              <tr class="bg-white text-gray-900 dark:bg-gray-800 dark:text-white">
                <th class="px-4 py-2 text-left text-xl" colspan="4">4.3- Vereficacion de esfuerzo cortante</th>
              </tr>
              <tr class="bg-gray-500 text-white dark:bg-gray-500 dark:text-white">
                <th class="text-xl" scope="col">Nombre</th>
                <th class="text-xl" scope="col">Simbolo</th>
                <th class="text-xl" scope="col">Formula</th>
                <th class="text-xl" scope="col">Resultado</th>
              </tr>
            </thead>
            <tbody class="py-2" id="modulo43"></tbody>

            <thead class="bg-gray-200 dark:bg-gray-700">
              <tr class="bg-white text-gray-900 dark:bg-gray-800 dark:text-white">
                <th class="px-4 py-2 text-left text-xl" colspan="4">4.4- Vereficacion de la estabilidad lateral
                </th>
              </tr>
              <tr class="bg-gray-500 text-white dark:bg-gray-500 dark:text-white">
                <th class="text-xl" scope="col">Nombre</th>
                <th class="text-xl" scope="col">Simbolo</th>
                <th class="text-xl" scope="col">Formula</th>
                <th class="text-xl" scope="col">Resultado</th>
              </tr>
            </thead>
            <tbody class="py-2" id="modulo44"></tbody>
            <thead class="bg-gray-200 dark:bg-gray-700">
              <tr class="bg-white text-gray-900 dark:bg-gray-800 dark:text-white">
                <th class="px-4 py-2 text-left text-xl" colspan="4">4.4- Vereficacion de la estabilidad lateral
                </th>
              </tr>
              <tr class="bg-gray-500 text-white dark:bg-gray-500 dark:text-white">
                <th class="text-xl" scope="col">Nombre</th>
                <th class="text-xl" scope="col">Simbolo</th>
                <th class="text-xl" scope="col">Formula</th>
                <th class="text-xl" scope="col">Resultado</th>
              </tr>
            </thead>
            <tbody class="py-2" id="modulo45"></tbody>

            <!-- Diseño del calculo del area del refuerzo  -->
            <thead class="bg-gray-200 dark:bg-gray-700"></thead>
            <tbody class="py-2" id="calcared"></tbody>

            <!-- Diseño por aceros para calcular el area por capas flexion-->
            <thead class="bg-gray-200 dark:bg-gray-700"></thead>
            <tbody class="py-2" id="acerosfinales"></tbody>

            <!-- Diseño por corte -->
            <!-- <thead class="bg-gray-200 dark:bg-gray-700">
                                    <tr class="bg-white text-gray-900 dark:bg-gray-800 dark:text-white">
                                        <th class="px-4 py-2 text-left text-xl" colspan="4">3.- Diseño por corte</th>
                                    </tr>
                                    <tr class="bg-gray-500 text-white dark:bg-gray-500 dark:text-white">
                                        <th class="text-xl" scope="col">Nombre</th>
                                        <th class="text-xl" scope="col">Simbolo</th>
                                        <th class="text-xl" scope="col">Formula</th>
                                        <th class="text-xl" scope="col">Resultado</th>
                                    </tr>
                                </thead>
                                <tbody class="py-2" id="diseñoCortes"></tbody> -->

            <!-- Diseño por aceros para calcular el area por capas corte -->
            <thead class="bg-gray-200 dark:bg-gray-700"></thead>
            <tbody class="py-2" id="aceroscortes"></tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</x-calc-layout>
