<svg viewBox="0 0 100 100">
    <polygon points="30,20 80,50 30,80" fill="black" />
</svg>
